var banco = {};

exports.db = banco;
