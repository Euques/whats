const cardapio0 = {
  1: {
    description: "Produto 1",
    price: "100.0",
  },
  2: {
    description: "Produto 2",
    price: "29.95",
  },
  3: {
    description: "Serviço 1",
    price: "425.50",
  },
};

exports.menu0 = cardapio0;
